def obtener_letra(letra, offset_y, z_seguro=0.35, z_escritura=0.3):
    # Aseguramos que offset_y sea un número
    offset_y = float(offset_y)
    
    libreria = {
        'S': [
            (0.0, 0.05 + offset_y, z_seguro),
            (0.0, 0.05 + offset_y, z_escritura),
            (0.0, 0.0 + offset_y, z_escritura),
            (0.025, 0.0 + offset_y, z_escritura),
            (0.025, 0.05 + offset_y, z_escritura),
            (0.05, 0.05 + offset_y, z_escritura),
            (0.05, 0.0 + offset_y, z_escritura),
            (0.05, 0.0 + offset_y, z_seguro)
        ],
        'A': [
            (0.05, 0.0 + offset_y, z_seguro),
            (0.05, 0.0 + offset_y, z_escritura),
            (0.0, 0.025 + offset_y, z_escritura),
            (0.05, 0.05 + offset_y, z_escritura),
            (0.05, 0.05 + offset_y, z_seguro),
            (0.025, 0.01 + offset_y, z_seguro),
            (0.025, 0.01 + offset_y, z_escritura),
            (0.025, 0.04 + offset_y, z_escritura),
            (0.025, 0.04 + offset_y, z_seguro)
        ],
        'P': [
            (0.05, 0.0 + offset_y, z_seguro),
            (0.05, 0.0 + offset_y, z_escritura),
            (0.0, 0.0 + offset_y, z_escritura),
            (0.0, 0.05 + offset_y, z_escritura),
            (0.025, 0.05 + offset_y, z_escritura),
            (0.025, 0.0 + offset_y, z_escritura),
            (0.025, 0.0 + offset_y, z_seguro)
        ]
    }
    
    # RETORNA SOLO LOS PUNTOS DE LA LETRA SOLICITADA
    # Si la letra no existe, retorna una lista vacía para no romper el programa
    return libreria.get(letra.upper(), [])