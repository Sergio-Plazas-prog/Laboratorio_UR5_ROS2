from setuptools import find_packages, setup

package_name = 'pkg_ure5'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='root',
    maintainer_email='root@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
            'console_scripts': [
                # Aquí defines el comando para la terminal
                # 'comando_en_terminal = carpeta.archivo:funcion'
                'dibujar_letras_exec = pkg_ure5.dibujar_letras:main',
            ],
        },
)
