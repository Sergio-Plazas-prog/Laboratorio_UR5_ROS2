import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor 
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_srvs.srv import Trigger 
import time
import threading  # <--- NUEVO: Para manejar el executor de fondo

# Cinemática y Matemáticas
import roboticstoolbox as rtb
from spatialmath import SE3
import numpy as np

# Importamos tu biblioteca
from .letras_db import obtener_letra

class DibujadorUR5e(Node):
    def __init__(self):
        super().__init__('dibujador_letras_node')
        
        # 1. Modelo del Robot para Cinemática Inversa (RTB)
        self.robot = rtb.models.DH.UR5()
        
        # 2. Cliente de Acción corregido
        self._action_client = ActionClient(
            self, 
            FollowJointTrajectory, 
            '/scaled_joint_trajectory_controller/follow_joint_trajectory'
        )

        # 3. Cliente de Servicio (Dashboard)
        self.popup_client = self.create_client(Trigger, '/ur_hardware_interface/dashboard/popup')
        
        self.ocupado = False
        self.get_logger().info('Nodo de Dibujo Inicializado - Threading Activo')

    def calcular_angulos_ik(self, x, y, z):
        """Traduce coordenadas cartesianas a ángulos (6 DOF)"""
        # Orientación: Herramienta mirando hacia abajo
        T = SE3(x, y, z) * SE3.OA([0, 1, 0], [0, 0, -1])
        solucion = self.robot.ikine_LM(T)
        return solucion.q

    def enviar_letra(self, puntos_xyz):
        """Pre-calcula la trayectoria y la envía al robot"""
        self.ocupado = True
        
        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory.joint_names = [
            'shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
            'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint'
        ]

        # --- PRE-CÁLCULO ---
        puntos_articulaciones = []
        for p in puntos_xyz:
            q = self.calcular_angulos_ik(p[0], p[1], p[2])
            puntos_articulaciones.append(q)

        # --- CONSTRUCCIÓN DEL MENSAJE (Optimizado para 5 Hz) ---
        t_ejecucion = 2.0
        for q in puntos_articulaciones:
            point = JointTrajectoryPoint()
            point.positions = q.tolist()
            point.time_from_start.sec = int(t_ejecucion)
            point.time_from_start.nanosec = int((t_ejecucion % 1) * 1e9)
            goal_msg.trajectory.points.append(point)
            t_ejecucion += 2.0 

        self.get_logger().info('Enviando trayectoria al controlador...')
        send_goal_future = self._action_client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Trayectoria rechazada')
            self.ocupado = False
            return
        
        self.get_logger().info('Moviendo brazo...')
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        self.get_logger().info('Letra finalizada correctamente')
        self.ocupado = False # <--- Esto ahora sí liberará el bucle while

def main(args=None):
    rclpy.init(args=args)
    nodo = DibujadorUR5e()

    # Configuramos el ejecutor multihilo
    executor = MultiThreadedExecutor()
    executor.add_node(nodo)

    # LANZAMOS EL EXECUTOR EN UN HILO APARTE
    # Esto permite que ROS procese respuestas mientras el código principal espera
    thread = threading.Thread(target=executor.spin, daemon=True)
    thread.start()

    if not nodo._action_client.wait_for_server(timeout_sec=10.0):
        nodo.get_logger().error('No se detecta el Action Server.')
        return

    palabra = "SPAP"
    x_inicio = 0.45 
    y_inicio = -0.10 

    for i, letra in enumerate(palabra):
        # El hilo de fondo actualizará 'nodo.ocupado' al terminar la letra
        while nodo.ocupado:
            time.sleep(0.1)

        nodo.get_logger().info(f'--- Empezando letra: {letra} ---')
        
        offset_y = y_inicio + (i * 0.12)
        puntos_relativos = obtener_letra(letra, offset_y, z_seguro=0.35, z_escritura=0.30)
        puntos_mundo = [(p[0] + x_inicio, p[1], p[2]) for p in puntos_relativos]
        
        nodo.enviar_letra(puntos_mundo)
        
        # Pequeña pausa para que el flag 'ocupado' se registre
        time.sleep(1.0)

    # Esperar a que la última letra termine antes de cerrar todo
    while nodo.ocupado:
        time.sleep(1.0)

    nodo.get_logger().info('¡Dibujo SPAP completado!')
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()